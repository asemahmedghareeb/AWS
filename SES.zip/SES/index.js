import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";


const sesClient = new SESClient({ region: "us-east-1",
    credentials: {
      accessKeyId: "AKIAQOWJ2H4RYM5D75VA",
      secretAccessKey: "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",
    },
 });

const sendTestEmail = async () => {
  const params = {
    Source: "asemelbadahy@gmail.com", // MUST match the verified email exactly
    Destination: {
      ToAddresses: ["asemelbadahy123@gmail.com"], // In Sandbox, you can only send to verified emails
    },
    Message: {
      Subject: { Data: "Test from Node.js" },
      Body: {
        Text: { Data: "Hello! This is a test email from AWS SES." },
      },
    },
  };

  try {
    const data = await sesClient.send(new SendEmailCommand(params));
    console.log("Success! Email sent. Message ID:", data.MessageId);
  } catch (err) {
    console.error("Error sending email:", err);
  }
};

sendTestEmail();
